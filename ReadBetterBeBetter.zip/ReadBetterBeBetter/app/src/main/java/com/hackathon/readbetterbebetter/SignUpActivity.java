package com.hackathon.readbetterbebetter;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener
{
    EditText entername;
    EditText password;
    EditText repassword;
    EditText editemail;
    EditText phone;
    DBHelper dbHelper;
    Button signupbutton;
    SQLiteDatabase ReadBetterBeBetterDB;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        signupbutton=findViewById(R.id.signupbutton);
        signupbutton.setOnClickListener((View.OnClickListener) this);

        entername=findViewById(R.id.entername);
        password=findViewById(R.id.password);
        repassword=findViewById(R.id.repassword);
        editemail=findViewById(R.id.editemail);
        phone=findViewById(R.id.phone);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == signupbutton.getId()) {
            if (validate())
            {

                insertData();
                displaydata();
                Intent loginIntent = new Intent(this, LogInActivity.class);
                startActivity(loginIntent);
            }
            else
            {
                Toast.makeText(this,"Enter Proper Details",Toast.LENGTH_LONG).show();
            }

        }
    }

    private void insertData()
    {
        String name = entername.getText().toString();
        String password1 = password.getText().toString();
        String email1 = editemail.getText().toString();
        String phone1 = phone.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("Name", name);
        cv.put("Password", password1);
        cv.put("Email", email1);
        cv.put("Phone", phone1);

        try
        {
            ReadBetterBeBetterDB = dbHelper.getWritableDatabase();
            ReadBetterBeBetterDB.insert("UserInfo", null, cv);
            Log.v("SignUp", "AccountCreated");

        }
        catch (Exception e)
        {
            Log.e("SignUp", e.getMessage());
        }
        finally
        {
            ReadBetterBeBetterDB.close();
        }
    }

    private void displaydata()
    {
        try
        {
            ReadBetterBeBetterDB = dbHelper.getReadableDatabase();
            String columns[] = {"Name","Password","Email","Phone"};

            Cursor cursor = ReadBetterBeBetterDB.query("UserInfo", columns,null,null,null,null,null);

            while (cursor.moveToNext())
            {
                String UserData = cursor.getString(cursor.getColumnIndex("Name"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Password"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Email"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Phone"));

                Toast.makeText(this,UserData,Toast.LENGTH_LONG).show();
            }

        }
        catch (Exception e)
        {
            Log.e("signUp",e.getMessage());
        }
        finally
        {
            ReadBetterBeBetterDB.close();
        }
    }

    public boolean validate() {
        boolean valid = true;

        String name = entername.getText().toString();
        String password1 = password.getText().toString();
        String repassword1 = repassword.getText().toString();
        String email=editemail.getText().toString();

        if (name.isEmpty())
        {
            entername.setError("Enter Name");
            valid = false;
        }
        else
        {
            entername.setError(null);
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editemail.setError("Enter a valid Email Address");
            valid = false;
        } else {
            editemail.setError(null);
        }

        if (password1.isEmpty() || password1.length() < 4 || password1.length() > 10)
        {
            password.setError("Enter Characters Betweeen 4 AND 10");
            valid = false;
        }
        else
        {
            password.setError(null);
        }

        if(!((repassword1.equals(password1))))
        {
            Toast.makeText(this, "Please Enter Same Password",
                    Toast.LENGTH_SHORT).show();
            valid = false;
        }

        return valid;
    }



}
