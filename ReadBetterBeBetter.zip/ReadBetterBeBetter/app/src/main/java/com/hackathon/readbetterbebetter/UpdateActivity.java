package com.hackathon.readbetterbebetter;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class UpdateActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnUpdate;
    DBHelper dbHelper;
    SQLiteDatabase ReadBetterBeBetterDB;
    Log_Information data = new Log_Information();
    String user = data.getLogged_in_user();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        btnUpdate = findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(this);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnUpdate.getId()){
            updateProfile();
            startActivity(new Intent(this,ProfileActivity.class));
        }
    }

    public void updateProfile(){
        EditText editName = findViewById(R.id.editName);
        EditText editPhone = findViewById(R.id.editMobile);

        String name = editName.getText().toString();
        String phone = editPhone.getText().toString();

        ContentValues cv = new  ContentValues();
        cv.put("Name",name);
        cv.put("Phone", phone);
        //cv.put("Email", user);

        try{
            ReadBetterBeBetterDB = dbHelper.getWritableDatabase();
            ReadBetterBeBetterDB.update("UserInfo", cv, "Email="+user, null);
            Log.v("ProfileActivity", "Successfully Updated");

        }catch (Exception e){
            Log.e("ProfileActivity", e.getMessage());
        }finally {
            ReadBetterBeBetterDB.close();
        }
    }
}
