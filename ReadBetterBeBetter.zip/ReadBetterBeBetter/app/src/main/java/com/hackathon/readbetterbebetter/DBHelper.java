package com.hackathon.readbetterbebetter;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DBName = "ReadBetterBeBetterDB";
    public static final String TBName_Posts = "Posts";
    public static final String TBName_UserInfo = "UserInfo";

    public DBHelper(Context context) {
        super(context, DBName, null, 3);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        try {

            String CREATE_TABLE_POSTS = "CREATE TABLE " + TBName_Posts +
                    "(Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,Topic VARCHAR(80),Post VARCHAR(555), Email VARCHAR(55))";

            Log.v("DBHelper", CREATE_TABLE_POSTS);
            sqLiteDatabase.execSQL(CREATE_TABLE_POSTS);

            String CREATE_TABLE = "CREATE TABLE " + TBName_UserInfo +
                    "(Name varchar(20), Password varchar(20), Email varchar(50) PRIMARY KEY, Phone varchar(20))";
            Log.v("DBHelper", CREATE_TABLE);
            sqLiteDatabase.execSQL(CREATE_TABLE);


        } catch (Exception e) {
            Log.e("DBHelper", e.getMessage());
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        try {
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TBName_Posts);
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TBName_UserInfo);
            onCreate(sqLiteDatabase);
        } catch (Exception e) {
            Log.e("DBHelper", e.getMessage());
        }

    }
}