package com.hackathon.readbetterbebetter;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class PostListAdapter extends BaseAdapter {

    LayoutInflater inflater;
    Context context;
    Log_Information data = new Log_Information();
    // String user = data.getLogged_in_user ();
    String user = "";

    DBHelper dbHelper;
    SQLiteDatabase ReadBetterBeBetterDB;

    ArrayList<String> title = new ArrayList<String>();
    ArrayList<String> post = new ArrayList<String>();

    public PostListAdapter(Context context) {
        this.context = context;
        inflater = LayoutInflater.from(this.context);
        this.dbHelper= new DBHelper(context);

        ReadBetterBeBetterDB = dbHelper.getReadableDatabase();
        String columns[] = {"Id","Topic","Post","Email"};

        Cursor cursor = ReadBetterBeBetterDB.query("Posts", columns,null,null,null,null,null);

        while (cursor.moveToNext()){
            if (cursor.moveToFirst()) {
                do {
                    title.add(cursor.getString(cursor
                            .getColumnIndex("Topic")));
                    post.add(cursor.getString(cursor
                            .getColumnIndex("Post")));
                } while (cursor.moveToNext());
            }
        }
        if(!cursor.isClosed()){
            cursor.close();
        }
    }


    @Override
    public int getCount() {
        return title.size ();
    }

    public void updateJobList() {

        ReadBetterBeBetterDB = dbHelper.getReadableDatabase();
        String columns[] = {"Id","Topic","Post","Email"};

        Cursor cursor = ReadBetterBeBetterDB.query("Posts", columns,null,null,null,null,null);
        title = new ArrayList<String>();
        post = new ArrayList<String>();

        while (cursor.moveToNext()){
            if (cursor.moveToFirst()) {
                do {
                    title.add(cursor.getString(cursor
                            .getColumnIndex("Topic")));
                    post.add(cursor.getString(cursor
                            .getColumnIndex("Post")));
                } while (cursor.moveToNext());
            }
        }
        if(!cursor.isClosed()){
            cursor.close();
        }
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        view = inflater.inflate(R.layout.post_list, null);

        TextView txtTitle = view.findViewById(R.id.txtTitle);
        txtTitle.setText(title.get(position));

        TextView txtPost = view.findViewById(R.id.txtPost);
        txtPost.setText(post.get(position));

        return view;
    }
}
