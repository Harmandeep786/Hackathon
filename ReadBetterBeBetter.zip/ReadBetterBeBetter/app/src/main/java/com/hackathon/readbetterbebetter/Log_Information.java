package com.hackathon.readbetterbebetter;

public class Log_Information
{


        private static String logged_in_user;

        public void setLogged_in_user(String username)
        {
            logged_in_user = username;
        }

        public String getLogged_in_user()
        {
            return logged_in_user;
        }

    }

