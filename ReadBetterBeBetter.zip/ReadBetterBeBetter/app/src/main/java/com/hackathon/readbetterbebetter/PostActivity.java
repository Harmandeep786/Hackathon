package com.hackathon.readbetterbebetter;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PostActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSubmitPost;
    EditText edtTopic;
    EditText edtPost;
    DBHelper dbHelper;
    SQLiteDatabase ReadBetterBeBetterDB;
    Log_Information data = new Log_Information();
    String user = data.getLogged_in_user();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_post);

        btnSubmitPost = findViewById (R.id.btnSubmitPost);
        btnSubmitPost.setOnClickListener(this);

        edtTopic = findViewById (R.id.edtTopic);
        edtPost = findViewById (R.id.edtPost);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnSubmitPost.getId()){

//            String data = edtName.getText().toString()+"\n"+
//            edtEmail.getText().toString()+"\n"+edtPassword.getText().toString()+"\n"+profile_type;
//            Toast.makeText(this,data,Toast.LENGTH_LONG).show();

            if(validate ()){
                insertData();
                displaydata();
                Intent homeIntent=new Intent(this,HomeActivity.class);
                startActivity(homeIntent);
            }
            else {
                Toast.makeText(this,"Enter proper details.",Toast.LENGTH_LONG).show();
            }

        }

    }

    private void insertData(){
        String topic = edtTopic.getText().toString();
        String post = edtPost.getText().toString();

        ContentValues cv = new  ContentValues();
        cv.put("Topic",topic);
        cv.put("Post", post);
        cv.put("Email", user);

        try{
            ReadBetterBeBetterDB = dbHelper.getWritableDatabase();
            ReadBetterBeBetterDB.insert("Posts", null, cv);
            Log.v("PostActivity", "Successfully Posted");

        }catch (Exception e){
            Log.e("PostActivity", e.getMessage());
        }finally {
            ReadBetterBeBetterDB.close();
        }


    }


    private void displaydata(){
        try{
            ReadBetterBeBetterDB = dbHelper.getReadableDatabase();
            String columns[] = {"Id","Topic","Post","Email"};

            Cursor cursor = ReadBetterBeBetterDB.query("Posts", columns,null,null,null,null,null);

            while (cursor.moveToNext()){
                String UserData = cursor.getString(cursor.getColumnIndex("Id"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Topic"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Post"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Email"));

                Toast.makeText(this,UserData,Toast.LENGTH_LONG).show();
            }

        }catch (Exception e){
            Log.e("PostActivity",e.getMessage());
        }finally {
            ReadBetterBeBetterDB.close();
        }
    }

    public boolean validate() {
        boolean valid = true;

        String topic = edtTopic.getText().toString();
        String post = edtPost.getText().toString();

        if (topic.isEmpty()) {
            edtTopic.setError("Enter Topic");
            valid = false;
        } else {
            edtTopic.setError(null);
        }

        if (post.isEmpty()) {
            edtPost.setError("Enter Post Data");
            valid = false;
        } else {
            edtPost.setError(null);
        }

        return valid;
    }
}